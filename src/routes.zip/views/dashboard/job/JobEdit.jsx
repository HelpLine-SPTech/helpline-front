import React from 'react'
import { DashboardSideBar } from '../../../components'

function JobEdit() {
  return (
    <div className='bg-green d-flex'>
      <DashboardSideBar />
      <div className='dash-content'>
        job edit
      </div>
    </div>
  )
}

export default JobEdit