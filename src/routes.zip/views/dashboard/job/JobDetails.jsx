import React from 'react'
import { DashboardSideBar } from '../../../components'

function JobDetails() {
  return (
    <div className='bg-green d-flex'>
      <DashboardSideBar />
      <div className='dash-content'>
        job detail
      </div>
    </div>
  )
}

export default JobDetails