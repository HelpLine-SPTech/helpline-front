import React from 'react'
import { DashboardSideBar } from '../../../components'

function JobAdd() {
  return (
    <div className='bg-green d-flex'>
      <DashboardSideBar />
      <div className='dash-content'>
        job add
      </div>
    </div>
  )
}

export default JobAdd